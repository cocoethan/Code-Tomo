package application.models;

import java.sql.Time;
import java.util.List;

import application.Database;
import application.Controllers.MainController;

public class AlarmModel {
	public static void addAlarmToDB() {
		
	}
	
	public static void removeAlarmFromDB() {
		
	}
}