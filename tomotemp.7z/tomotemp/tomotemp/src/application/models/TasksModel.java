package application.models;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.List;

import application.Database;
import application.Controllers.MainController;

public class TasksModel{
	
	public static void addNewTaskToDB(List<String> currTask) throws SQLException {
		String name = currTask.get(0);
		String priority = currTask.get(1);
		String date = currTask.get(2);
		
		MainController.updateUpdatesList("New task added. +5");
		Database.editTamoPts(5);
		System.out.println("Task Added: " + currTask);
		
		Database.getAlarm();
		//begin code
		//FOR LANE DEESE
		if(date != null) {
			Date locDate = Date.valueOf(date);
			Database.placeReminder(name, null, null , locDate, priority);
		}
		else {
			Database.placeReminder(name, null, null , null, priority);
		}
		
		//code for loading previous reminders
		String[] rID = Database.getReminderID();
		Date[] rDate = Database.getReminderDate();
		String[] rPriority = Database.getReminderPriority();
		int length = rID.length;
		int i = 0;
		while(i < length) {
			String currID = rID[i];
			Date currDate = rDate[i];
			String currPrio = rPriority[i];
			//load values into i pos in database
			i++;
		}
		//end load into app
	}
	
	public static void deleteTaskToDB(List<String> currTask) {
		String name = currTask.get(0);
		String priority = currTask.get(1);
		String date = currTask.get(2);
		
		try {
			Database.removeReminder(name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MainController.updateUpdatesList("Task removed.");
		System.out.println("Task Deleted: " + currTask);
		
		//begin code
		
		
	}
}