package application.models;

public class TasksModel{
	public static void addNewTaskToDB(String taskTitle) {
		//!!! FOR LANE DEESE
		//Add Task to Database here
		
	}
}